#Author: Jackson Ross jrr4557
#Homework 10 - GUI Co-Op Purchasing Window
#Due Date: 11/29/17
#Description: This file creates an instance of the GUI class PurchaseWindow for the user to interact with.

#import the GUI class
import purchasewindow

#define main function
def main():

    #create an instance of the GUI window
    coop_window = purchasewindow.PurchaseWindow()

#run main function
main()
