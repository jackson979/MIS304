#Author: Jackson Ross jrr4557
#Homework 10 - GUI Co-Op Purchasing Window
#Due Date: 11/29/17
#Description: This file contains the class for the GUI window. It includes all of the buttons, frames, and labels used for the window as well as
                #some feautures such as an exit button and a button which displays an invoice to the user based on their choices.

#import the tkinter libraries
import tkinter
import tkinter.messagebox

#set constants for prices
HAT_PRICE = 21.99
MUG_PRICE = 10.99
SHIRT_PRICE = 26.00
SHIPPING_SLOW = 1.99
SHIPPING_MEDIUM = 2.99
SHIPPING_FAST = 5.99

#define the PurchaseWindow class
class PurchaseWindow:

    #define the initialization of the PurchaseWindow class
    def __init__(self):

        #create main window and label for main window
        self.main_window = tkinter.Tk()
        self.window_label = tkinter.Label(self.main_window, text = 'Co-Op Purchase Menu')

        #create variables for the user choices so they can be gotten later price calculation
        self.hat = tkinter.IntVar()
        self.mug = tkinter.IntVar()
        self.shirt = tkinter.IntVar()
        self.shipping = tkinter.IntVar()

        #create top frame and label for top frame
        self.top_frame = tkinter.Frame(self.main_window)
        self.top_frame_label = tkinter.Label(self.top_frame, text = '\nProducts')

        #create product Checkbuttons, assigning an onvalue or offvalue to the variables created above to use for price calculation
        self.hat_button = tkinter.Checkbutton(self.top_frame,text = 'UT Hat\t\t$21.99', variable = self.hat, onvalue = 1, offvalue = 0)
        self.mug_button = tkinter.Checkbutton(self.top_frame,text = 'UT Mug\t\t$10.99', variable = self.mug, onvalue = 1, offvalue = 0)
        self.shirt_button = tkinter.Checkbutton(self.top_frame,text = 'UT T-shirt\t$26.00', variable = self.shirt, onvalue = 1, offvalue = 0)

        #create bottom frame and label for bottom frame
        self.bottom_frame = tkinter.Frame(self.main_window)
        self.bottom_frame_label = tkinter.Label(self.bottom_frame, text = '\nShipping')

        #create shipping Radiobuttons, assigning a value to the shipping variable based on which button is selected, used for price calculation
        self.slow_shipping_button = tkinter.Radiobutton(self.bottom_frame, text = '3-5 days - $1.99', variable = self.shipping, value = 1)
        self.medium_shipping_button = tkinter.Radiobutton(self.bottom_frame, text = '2 days - $2.99', variable = self.shipping, value = 2)
        self.fast_shipping_button = tkinter.Radiobutton(self.bottom_frame, text = '1 day - $5.99', variable = self.shipping, value = 3)

        #have the 3-5 shipping button selected by default
        self.slow_shipping_button.select()

        #create checkut and done buttons that display an invoice window and close the program respectively
        self.checkout_button = tkinter.Button(self.bottom_frame, text = 'Checkout', command = self.print_invoice)
        self.done_button = tkinter.Button(self.bottom_frame, text = 'Done', command = self.main_window.destroy)

        #pack window label first
        self.window_label.pack()

        #pack top frame and label
        self.top_frame.pack()
        self.top_frame_label.pack()

        #pack Checkbuttons
        self.hat_button.pack()
        self.mug_button.pack()
        self.shirt_button.pack()

        #pack bottom frame and label
        self.bottom_frame.pack()
        self.bottom_frame_label.pack()

        #pack Radiobuttons and checkout and done buttons
        self.slow_shipping_button.pack()
        self.medium_shipping_button.pack()
        self.fast_shipping_button.pack()
        self.checkout_button.pack()
        self.done_button.pack()

        #call mainloop() to display window
        tkinter.mainloop()

    #define function that will print the invoice
    def print_invoice(self):
        
        #create starting variables of 0
        subtotal = 0
        ship = 0

        #get the value that was assigned to each self.*product* when the button was selected
        hat = self.hat.get()
        mug = self.mug.get()
        shirt = self.shirt.get()
        shipping = self.shipping.get()
        
        #if the value is 1 (i.e. the button was selected), add the price of the item to the subtotal
        if hat == 1:
            subtotal += HAT_PRICE
        if mug == 1:
            subtotal += MUG_PRICE
        if shirt == 1:
            subtotal += SHIRT_PRICE

        #check the value (each button assigned a different value depending on the shipping option chosen) and assign the correct shipping cost based on the value
        if shipping == 1:
            ship = SHIPPING_SLOW
        if shipping == 2:
            ship = SHIPPING_MEDIUM
        if shipping == 3:
            ship = SHIPPING_FAST

        #calculate total
        total = ship + subtotal

        #print the invoice to a separate window
        tkinter.messagebox.showinfo('Invoice', 'Subtotal:\t$' + str(format(subtotal,',.2f')) + '\nShipping:\t$' + str(format(ship,',.2f')) + '\nTotal:\t\t$' + str(format(total,',.2f')))
