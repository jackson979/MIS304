#Author: Jackson Ross jrr4557
#Homework 8 - Cell Phone Usage
#Due Date: 11/13/17
#Description: This program is the class file used for HW8; it creates an object
    #that keeps track of a name, account number, texts, and minutes and can use
    #that information to print a billing statement for the account.

#declare global constants for prices, rates, and limits
MINUTE_LIMIT = 500
TEXT_LIMIT = 100
MINUTE_OVERAGE_RATE = .25
TEXT_OVERAGE_RATE = .20
MONTHLY_RATE = 79.95
TAX_RATE = .0825

#class definition
class CellPhoneUsage:

    #initiation function
    def __init__(self):
        #initialize class values and hide them
        self.__account_num = 0
        self.__account_name = 'N/A'
        self.__minutes_used = 0
        self.__texts_sent = 0
        self.__calls_made = 0

    #function that returns the account number
    def get_account_num(self):
        return self.__account_num

    #function that changes the value of the account number
    def set_account_num(self,num):
        #validate input before setting the new number and return true
        if num > 0:
            self.__account_num = num
            return True
        
        #else return false to the main program so it can get new user input
        else:
            return False

    #function that returns the account name
    def get_account_name(self):
        return self.__account_name

    #function that changes the value of the account name
    def set_account_name(self,name):
        self.__account_name = name

    #function that returns the number of minutes
    def get_minutes_used(self):
        return self.__minutes_used

    #function that adds minutes to the minute counter for the class and increases the call counter
    def make_call(self,new_minutes):
        #validate input before setting the new number and return true
        if new_minutes > 0:
            self.__calls_made += 1
            self.__minutes_used += new_minutes
            return True
        
        #else return false to the main program so it can get new user input
        else:
            return False

    #function that returns the number of texts sent
    def get_texts_sent(self):
        return self.__texts_sent

    #function that adds a number of texts to the text counter for the class
    #returns true or false to validate user input
    def send_texts(self,new_texts_sent):
        if new_texts_sent > 0:
            self.__texts_sent += new_texts_sent
            return True
        else:
            return False

    #function that calculates the overage charge for minutes if they exceeded the minute limit
    def calculate_minutes_charge(self):
        if self.__minutes_used > MINUTE_LIMIT:
            overage = self.__minutes_used - MINUTE_LIMIT
            overage_charge = overage * MINUTE_OVERAGE_RATE
        else:
            overage_charge = 0
        return overage_charge

    #function that calculates the overage charge for textx if they exceeded the text limit
    def calculate_texts_charge(self):
        if self.__texts_sent > TEXT_LIMIT:
            overage = self.__texts_sent - TEXT_LIMIT
            overage_charge = overage * TEXT_OVERAGE_RATE
        else:
            overage_charge = 0
        return overage_charge

    #function that adds the monthly rate to the overage charges (if any) and returns that value
    def calculate_total(self):
        call_overage = self.calculate_minutes_charge()
        text_overage = self.calculate_texts_charge()
        total = MONTHLY_RATE + call_overage + text_overage
        return total

    #function that calculates a subtotal, tax, and total; then displays a bill
    def display_bill(self):
        #get overage charges
        call_overage = self.calculate_minutes_charge()
        text_overage = self.calculate_texts_charge()

        #calculate the subtotal
        subtotal = self.calculate_total()

        #calculate tax using the constant rate
        tax = TAX_RATE * subtotal

        #add the tax tot he subtotal for the total
        total = subtotal + tax

        #print each line of the bill
        print('------ Cell Phone Bill ------')
        print('Account Number:\t\t',self.__account_num)
        print('Account Name:\t\t',self.__account_name)
        print('Minutes Allowed:\t',MINUTE_LIMIT)
        print('Minutes Used:\t\t',self.__minutes_used)
        print('Minutes Overage Charge:\t$',format(call_overage,',.2f'),sep='')
        print('Texts Allowed:\t\t',TEXT_LIMIT)
        print('Texts Used:\t\t',self.__texts_sent)
        print('Texts Overage Charge:\t$',format(text_overage,',.2f'),sep='')
        print('Total Pre-Tax Bill:\t$',format(subtotal,',.2f'),sep='')
        print('Tax Amount:\t\t$',format(tax,',.2f'),sep='')
        print('Total Due:\t\t$',format(total,',.2f'),sep='')
        
    #function that is called by printing the object; used for 'View Current Usage' menu option
    def __str__(self):
        var = 'Acct Number: ' + str(self.__account_num) + ', Name: ' + self.__account_name + '; Calls: ' + str(self.__calls_made) + ' for ' + str(self.__minutes_used) + ' minutes' + ', Texts: ' + str(self.__texts_sent)
        return var
