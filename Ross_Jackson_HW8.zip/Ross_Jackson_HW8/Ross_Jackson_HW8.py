#Author: Jackson Ross jrr4557
#Homework 8 - Cell Phone Usage
#Due Date: 11/13/17
#Description: This program creates an instance of an object and uses that object to track cell phone usage (calls and texts) as well as create a bill based on usage.

#import class file
import cellphoneusage

#create global constants for menu options
UPDATE_ACCT = 1
MAKE_CALL = 2
SEND_TEXTS = 3
VIEW_USAGE = 4
FINALIZE = 5

#function that displays the menu
def display_menu():
    #print each line of the menu
    print('1. Update account info')
    print('2. Make call')
    print('3. Send texts')
    print('4. View current usage')
    print('5. Finalize bill')
    print()

#function that gets user input for menu choice and validates it
def user_choice():
    #get user input
    choice = int(input('Enter menu choice: '))
    print()

    #validate user input
    while choice < UPDATE_ACCT or choice > FINALIZE:
        choice = int(input('Invalid input. Please enter a number between 1 and 5: '))
        print()

    #return valid choice
    return choice

#main function
def main():
    #create instance of the object
    acct1 = cellphoneusage.CellPhoneUsage()

    #display menu and get user input
    display_menu()
    menu = user_choice()

    #while loop until the user wants to finalize their bill
    while menu != FINALIZE:
        #if they select menu option 1
        if menu == UPDATE_ACCT:
            #get the current account name and number from the object and print them
            current_num = acct1.get_account_num()
            current_name = acct1.get_account_name()
            print('Account Number:',current_num)
            print('Account Name:',current_name)
            print()

            #get user input to change the account number
            new_num = int(input('Enter new account number: '))
            print()

            #validate user input using value returned from set_account_num()
            valid = acct1.set_account_num(new_num)

            #while false
            while valid == False:
                #get new input
                new_num = int(input('Invalid input. Enter a positive account number: '))
                print()

                #call the function again until it returns true
                valid = acct1.set_account_num(new_num)

            #get user input to change the account name
            new_name = input('Enter new account name: ')

            #change account name
            acct1.set_account_name(new_name)
            print()

        #if they select menu option 2           
        elif menu == MAKE_CALL:
            #get user input for minutes for each call
            minutes = int(input('Enter the length of the call in minutes: '))
            print()

            #validate user input using value returned from make_call()
            valid = acct1.make_call(minutes)
            while valid == False:
                minutes = int(input('Invalid input. Enter a positive call length: '))
                print()
                valid = acct1.make_call(minutes)

        #if they select menu option 3
        elif menu == SEND_TEXTS:
            #get user input for texts sent
            texts = int(input('Enter the number of texts sent: '))
            print()
            
            #validate user input using value returned from make_call()
            valid = acct1.send_texts(texts)
            while valid == False:
                texts = int(input('Invalid input. Enter a positive number of texts: '))
                print()
                valid = acct1.send_texts(texts)

        #if they select menu option 4
        else:
            #call the __str__() class function for the summary
            print(acct1)
            print()

        #display menu and get user input
        display_menu()
        menu = user_choice()

    #call class function to display customer bill and end program
    acct1.display_bill()

#call main function
main()
