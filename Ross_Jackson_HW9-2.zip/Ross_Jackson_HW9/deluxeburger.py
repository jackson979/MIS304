#Author: Jackson Ross jrr4557
#Homework 9 - Ordering Entrees
#Due Date: 11/20/17
#Description:

#import the superclass
import plainburger

CHEESE_COST = .99
BACON_COST = 1.79
AVOCADO_COST = 1.99

#create class, including the parent in the parenthesis
class DeluxeBurger(plainburger.PlainBurger):
    #function that initializes object
    def __init__(self,entree_name,quantity,burger_size):
        #initialize the parent using the name, quantity, and size passed from the main program
        super().__init__(entree_name,quantity,burger_size)

        #start with all topping variables as True
        self.__cheese = True
        self.__bacon = True
        self.__avocado = True

    #accessor function that returns True or False
    def get_cheese(self):
        return self.__cheese
    
    #accessor function that returns True or False
    def get_bacon(self):
        return self.__bacon

    #accessor function that returns True or False
    def get_avocado(self):
        return self.__avocado

    #mutator function that sets variable to False
    def remove_cheese(self):
        self.__cheese = False

    #mutator function that sets variable to False
    def remove_bacon(self):
        self.__bacon = False

    #mutator function that sets variable to False
    def remove_avocado(self):
        self.__avocado = False

    #function that calculates the cost of the burger based on the size and the additional toppings
    def calc_cost(self):
        #call the get_price() class function from the superclass and store it as the base price
        plain_cost = self.get_price()

        #call the get_qty() class function from the super-superclass and store it
        qty = self.get_qty()
        
        #calculate additional cost based on the toppings on the burger
        additional_cost = 0
        if self.__cheese == True:
            additional_cost += CHEESE_COST
        if self.__bacon == True:
            additional_cost += BACON_COST
        if self.__avocado == True:
            additional_cost += AVOCADO_COST

        #calculate the total cost using the base cost, the additional cost, and the quantity
        cost = (plain_cost + additional_cost) * qty

        return cost

    #function that returns a string when called, used for printing objects
    def __str__(self):
        #call various class functions to get the cost, size, quantity, and name; store them as variables
        cost = self.calc_cost()
        size = self.get_size()
        qty = self.get_qty()
        name = self.get_name()

        #create a new string that can store the toppings based on whether or not they are True or False
        toppings_str = ''
        if self.__cheese == True:
            toppings_str += 'cheese '
        if self.__bacon == True:
            toppings_str += 'bacon '
        if self.__avocado == True:
            toppings_str += 'avocado '

        #put all of the pieces together to form the final string
        string = str(qty) + ' ' + name + ' ' + str(size) + 'oz Toppings: ' + toppings_str + '$' + str(format(cost,'.2f'))
        return string
