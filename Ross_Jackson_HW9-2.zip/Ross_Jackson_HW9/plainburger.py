#Author: Jackson Ross jrr4557
#Homework 9 - Ordering Entrees
#Due Date: 11/20/17
#Description: This file contains the subclass PlainBurger which extends Entree and adds unique attributes.

#import the superclass
import entree

#create global constants
PRICE_6OZ = 5.99
PRICE_8OZ = 7.99
PRICE_10OZ = 9.99

#create class, including the parent in the parenthesis
class PlainBurger(entree.Entree):
    #function that initializes object
    def __init__(self,entree_name,quantity,burger_size):
        #initialize the parent using the name and quantity passed from the user
        super().__init__(entree_name,quantity)

        #set the size equal to the value passed in from the main program
        self.__size = burger_size

        #call set_price() class function, passing it the size
        self.__price = self.set_price(self.__size)
        
    #accessor function that returns the size of the burger
    def get_size(self):
        return self.__size

    #mutator function that uses the size of the burger to determine price
    def set_price(self,sz):
        if sz == 6:
            pri = PRICE_6OZ
        elif sz == 8:
            pri = PRICE_8OZ
        else:
            pri = PRICE_10OZ
        return pri
        
    #accessor function that returns the price of the burger
    def get_price(self):
        return self.__price

    #function that calculates the cost of the burger based on both size and quantity
    def calc_cost(self):
        #call the get_qty() class function form the superclass and store it
        quant = self.get_qty()
        cost = self.__price * quant
        return cost

    #function that returns a string when called, used for printing objects
    def __str__(self):
        #call calc_cost() class function and store it in a variable
        cost = self.calc_cost()

        #define the string by first calling the parent's __str__() function then adding the new attributes
        string = super().__str__() + ' ' + str(self.__size) + 'oz $' + str(format(cost,'.2f'))
        return string
