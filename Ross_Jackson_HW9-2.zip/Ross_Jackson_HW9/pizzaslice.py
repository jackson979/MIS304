#Author: Jackson Ross jrr4557
#Homework 9 - Ordering Entrees
#Due Date: 11/20/17
#Description: This file contains the subclass PizzaSlice which extends Entree and adds unique attributes.

#import the superclass
import entree

#create constants for prices
PIZZA_PRICE = 1.99
TOPPING_PRICE  = .99

#create class, including the parent in the parenthesis
class PizzaSlice(entree.Entree):
    #function that initializes object
    def __init__(self,entree_name,quantity,topping_num):
        #initialize the parent using the name and quantity passed from the user
        super().__init__(entree_name,quantity)

        #set the number of toppings equal to the value passed in from the main program
        self.__toppings = topping_num

    #accessor function that returns the number of toppings
    def get_toppings(self):
        return self.__toppings

    #function that calculates the cost of the pizza based on the number of slices and the cost of each topping
    def calc_cost(self):
        qty = self.get_qty()
        cost = (PIZZA_PRICE + (self.__toppings * TOPPING_PRICE)) * qty
        return cost

    #function that returns a string when called, used for printing objects
    def __str__(self):
        #call calc_cost() class function and store it in a variable
        cost = self.calc_cost()

        #define the string by first callinfg the parent's __str__() function than adding the new attributes
        string = super().__str__() + ' ' + str(self.__toppings) + ' Toppings $' + str(format(cost,'.2f'))
        return string
