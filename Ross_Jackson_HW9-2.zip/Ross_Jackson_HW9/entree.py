#Author: Jackson Ross jrr4557
#Homework 9 - Ordering Entrees
#Due Date: 11/20/17
#Description: This file contains the superclass Entree which contains the common attributes of the menu items (quantity and name).

#create class
class Entree():
    #function that initializes the object
    def __init__(self,entree_name,quantity):
        #set the name and qty equal to the values passed in from the main program
        self.__name = entree_name
        self.__qty = quantity

    #accessor function that returns the name of the item
    def get_name(self):
        return self.__name

    #accessor function that returns the quantity of items purchased
    def get_qty(self):
        return self.__qty

    #function that returns a string when called, used for printing objects
    def __str__(self):
        #define the string witht he attributes and return the string when finished
        string = str(self.__qty) + ' ' + self.__name
        return string
        
