#Author: Jackson Ross jrr4557
#Homework 9 - Ordering Entrees
#Due Date: 11/20/17
#Description: This program takes menu input from a user and creates an object for each item chosen. These objects can be manipulated and then used to print an invoice for the user.

#import class files
import entree
import pizzaslice
import plainburger
import deluxeburger

#create menu sentinels
MENU_PIZZA = 1
MENU_PLAIN_BURGER = 2
MENU_DELUXE_BURGER = 3
MENU_EXIT = 4

#create constant for tax rate
TAX_RATE = .0825

#function that prints menu to the screen
def display_menu():
    print('1. Pizza slice')
    print('2. Plain burger')
    print('3. Deluxe burger')
    print('4. Complete order')
    print()

#function that gets user choice for the menu and validates input
def get_choice():
    #get user input
    choice = int(input('Enter a menu option: '))
    print()

    #use sentinels in expression
    while choice < MENU_PIZZA or choice > MENU_EXIT:
        choice = int(input('Invalid input. Please enter a valid menu option: '))
        print()
    return choice

#function that gets user input for quantity and validates that it is > 0
def get_quantity():
    #get user input
    quantity = int(input('How many would you like? '))
    print()

    #validate input
    while quantity <= 0:
        quantity = int(input('Invalid input. Please enter a positive quantity: '))
        print()
    return quantity

#function that prints the final invoice
def print_invoice(ord_list,count):
    #assign value to counter and create new subtotal
    total_items = count
    subtotal = 0

    #loop through the list of items
    for item in ord_list:
        #call cal_cost() class function and add that to the subtotal
        price = item.calc_cost()
        subtotal += price

        #call the __str__() function for each item
        print(item)

    #calculate the amount of tax
    tax_amount = TAX_RATE * subtotal

    #calculate total amount due
    total_due = subtotal + tax_amount

    #print summary info
    print()
    print('Total entrees purchased:\t',total_items)
    print('Subtotal:\t\t\t$',format(subtotal,'.2f'),sep='')
    print('Tax:\t\t\t\t$',format(tax_amount,'.2f'),sep='')
    print('Total due:\t\t\t$',format(total_due,'.2f'),sep='')
        
#main program function
def main():
    #print menu
    display_menu()
    
    #get user input
    user_choice = get_choice()

    #create empty list and item counter
    order_list = []
    total_items = 0

    #if the user does not select any items, do not print invoice, just thank them and end program
    if user_choice == MENU_EXIT:
        print('Thank you for visiting!')

    #otherwise do this
    else:
        #keeps running until the user selects menu option to end
        while user_choice != MENU_EXIT:
            #if the user chose pizza slices
            if user_choice == MENU_PIZZA:
                #get quantity input from user and use it to update the item counter
                quantity = get_quantity()
                total_items += quantity

                #get toping quantity input and validate that it is positive
                topping_num = int(input('How many toppings would you like? '))
                print()
                while topping_num < 0:
                    topping_num = int(input('Invalid input. Please enter a non-negative topping quantity: '))
                    print()

                #create instance of PizzaSlice class using the quantity and toppings input by the user
                pizza = pizzaslice.PizzaSlice('Pizza Slice',quantity,topping_num)

                #add the object to the list
                order_list.append(pizza)

            #if the user chose the plain burger
            elif user_choice == MENU_PLAIN_BURGER:
                #get quantity input from user and use it to update the item counter
                quantity = get_quantity()
                total_items += quantity

                #get burger size input and validate that it is 6, 8, or 10
                burger_size = int(input('Enter burger size (6oz., 8oz., or 10oz.): '))
                print()
                while burger_size != 6 and burger_size != 8 and burger_size != 10:
                    burger_size = int(input('Invalid input. Please enter a correct burger size (6oz., 8oz., or 10oz.): '))
                    print()

                #create instance of PlainBurger class using the quantity and size input by the user
                burger = plainburger.PlainBurger('Plain Burger',quantity,burger_size)

                #add the object to the list
                order_list.append(burger)

            #if the user chose the deluxe burger
            elif user_choice == MENU_DELUXE_BURGER:
                #get quantity input from user and use it to update the item counter
                quantity = get_quantity()
                total_items += quantity
                
                #get burger size input and validate that it is 6, 8, or 10               
                burger_size = int(input('Enter burger size (6oz., 8oz., or 10oz.): '))
                print()
                while burger_size != 6 and burger_size != 8 and burger_size != 10:
                    burger_size = int(input('Invalid input. Please enter a correct burger size (6oz., 8oz., or 10oz.): '))
                    print()

                #create instance of DeluxeBurger class using the quantity and size input by the user
                burger = deluxeburger.DeluxeBurger('Deluxe Burger',quantity,burger_size)

                #get user choice on cheese and validate that it is Y or N
                cheese_choice = input('Would you like cheese (Y or N)? ')
                print()
                while cheese_choice != 'Y' and cheese_choice != 'N':
                    cheese_choice = input('Please enter Y if you would like cheese, or N if you would not like cheese: ')
                    print()

                #if the user does not want cheese, call the remove_cheese() class function
                if cheese_choice == 'N':
                    burger.remove_cheese()
                    
                #get user choice on bacon and validate that it is Y or N
                bacon_choice = input('Would you like bacon (Y or N)? ')
                print()
                while bacon_choice != 'Y' and bacon_choice != 'N':
                    bacon_choice = input('Please enter Y if you would like bacon, or N if you would not like bacon: ')
                    print()

                #if the user does not want bacon, call the remove_bacon() class function
                if bacon_choice == 'N':
                    burger.remove_bacon()

                #get user choice on avocado and validate that it is Y or N
                avocado_choice = input('Would you like avocado (Y or N)? ')
                print()
                while avocado_choice != 'Y' and avocado_choice != 'N':
                    avocado_choice = input('Please enter Y if you would like avocado, or N if you would not like avocado: ')
                    print()

                #if the user does not want avocado, call the remove_avocado() class function
                if avocado_choice == 'N':
                    burger.remove_avocado()

                #add the object to the list
                order_list.append(burger)

            #print menu again
            display_menu()

            #get new menu choice from user
            user_choice = get_choice()

        #call function to print the final invoice, passing it the list and the total item counter
        print_invoice(order_list,total_items)

#call main function
main()
    
