#Authors: Chris Simon & Jackson Ross
#Final Project - Airline Ticket Manager
#Due Date: 12/14/17
#Description: This program defines a ticket class, with all of the necessary attributes and functions, that is to be used in the main program file. 

#declare global constants
FIRST_CLASS = 2
BUSINESS_SELECT = 1.5

#declare ticket class
class Ticket:

    #declare init function
    def __init__(self, new_ticket_no, new_name, new_flight_no, new_seat):
        #declare attribute values using the parameters
        self.__ticket_number = new_ticket_no
        self.__passenger_name = new_name
        self.__flight_number = new_flight_no
        self.__seat = new_seat

    #declare ticket number accessor
    def get_ticket_number(self):
        return self.__ticket_number

    #declare passenger name accessor
    def get_passenger_name(self):
        return self.__passenger_name

    #declare flight number accessor
    def get_flight_number(self):
        return self.__flight_number

    #declare seat accessor
    def get_seat(self):
        return self.__seat

    #declare seat mutator
    def set_seat(self, new_seat):
        self.__seat = new_seat
        
    #declare function to calculate price based on base price and row
    def calc_price(self, base_price):
        #use the length of the seat string to determine where the row digits will be
        #and slice the string to get the row number
        length = len(self.__seat)
        if length == 2:
            row = int(self.__seat[0])
        elif length == 3:
            row = int(self.__seat[0:2])

        #based on the row number, determine the ticket markup and apply it to the price
        if row <= 3:
            price = (FIRST_CLASS*base_price) + base_price
        elif row > 3 and row <= 10:
            price = (BUSINESS_SELECT*base_price) + base_price
        else:
            price = base_price
        #return the final price value to the function call
        return price

    #declare str function
    def __str__(self):
        #create and return a string with the ticket attributes listed
        string = "Passenger name: " + self.__passenger_name + "\tSeat: " + self.__seat
        return string

        
