#Authors: Chris Simon & Jackson Ross
#Final Project - Airline Ticket Manager
#Due Date: 12/14/17
#Description: This program contains the main program which allows the user to purchase, cancel, view, and change tickets
                #as well as view the seat map for a flight, and write an output file with the ticket information

#global constants
FLIGHTS_INPUT_FILE = 'flights.txt'
TICKETS_INPUT_FILE = 'tickets.txt'
OUTPUT_FILE = 'tickets-updated.txt'

#declare menu sentinels
PURCHASE_TICKET = 1
CANCEL_TICKET = 2
VIEW_TICKET = 3
VIEW_SEAT_MAP = 4
CHANGE_SEAT = 5
DONE = 6

#import classes
import flight
import ticket
import random

#declare function to display the menu
def print_menu():
    print("1. Purchase ticket")
    print("2. Cancel ticket")
    print("3. View ticket")
    print("4. View seat map")
    print("5. Change seat")
    print("6. Done")
    print()

#declare function to get user input for menu option
def get_menu_option():
    #get user input
    choice = int(input("Enter the number of the action you would like to perform: "))
    print()
    
    #validate user input using sentinels
    while choice < PURCHASE_TICKET or choice > DONE:
        print("Invalid entry. Number must be between 1 and 6.")
        print()
        #get user input again
        choice = int(input("Enter the number of the action you would like to perform: "))
        print()

    #return the user's choice
    return choice

#declare function to purchase a ticket, passing it the flight and ticket dictionaries
def purchase_ticket(flight_dic,ticket_dic):
    #get user input for passenger name
    passenger_name = input("Enter passenger's name: ")
    print()

    #display all of the flights in the flight dictionarycalling the flight class's str function
    for flight in flight_dic:
        #call the flight class's __str__ function
        print(flight_dic[flight])
    print()

    #get user input for desired flight    
    flight_number = int(input("Enter flight number of flight you'd like to purchase: "))
    print()

    #validate that flight is available
    while flight_number not in flight_dic:
        #get user input again
        flight_number = int(input("Invalid flight number. Please re-enter flight number: "))
        print()

    #display the seat map for the flight for the user to see    
    view_seat_map(flight_number,flight_dic)

    #get user input for desired seat
    seat = input("Enter seat you would like to purchase: ")
    print()

    #call the assign seat function and use the returned value to validate if the seat is taken or not
    valid = flight_dic[flight_number].assign_seat(seat)
    while valid == False:
        #get user input again
        seat = input("Enter seat you would like to purchase: ")
        print()

        #re-call the assign seat function to restart the while loop
        valid = flight_dic[flight_number].assign_seat(seat)

    #generate a random, 8-digit number for the ticket
    ticket_number = random.randint(10000000,100000000)

    #check if the random number is already being used
    while ticket_number in ticket_dic:
        #generate a new random number to restart the loop
        ticket_number = random.randint(10000000,100000000)

    #create an instance of ticket
    new_ticket = ticket.Ticket(ticket_number, passenger_name, flight_number, seat)

    #add the instance to ticket dict using the randomly-generated ticket_number
    ticket_dic[ticket_number] = new_ticket

    #print new ticket number
    print("Your ticket number is " + str(ticket_number))
    print()

#declare function to process the ticket input file, passing it the flight and ticket dictionaries and the file name
def process_tickets(file_name,dictionary,flights):
    #open the ticket input file
    ticket_file = open(file_name,'r')

    #go through each line in the file
    for line in ticket_file:
        #strip the line then split it into a list
        line = line.rstrip('\n')
        line_list = line.split('^')

        #assign the proper variables using the list
        ticket_num = int(line_list[0])
        pass_name = line_list[1]
        flight_num = int(line_list[2])
        seat = line_list[3]

        #call the assign seat function and store the returned value
        valid = flights[flight_num].assign_seat(seat)

        #if the value is false, print a brief error message
        if valid == False:
            print('An error occured when processing the data file.')

        #create an instance of ticket
        new_ticket = ticket.Ticket(ticket_num,pass_name,flight_num,seat)

        #add the ticket to the dictionary
        dictionary[ticket_num] = new_ticket

    #close the input file
    ticket_file.close()

#declare function to process the flight input file, passing it the flight and ticket dictionaries and the file name
def process_flights(file_name,dictionary):
    #open the ticket input file
    flight_file = open(file_name,'r')

    #go through each line in the file
    for line in flight_file:
        #strip the line then split it into a list
        line.rstrip('\n')
        line_list = line.split('^')

        #assign the proper variables using the list
        flight_num = int(line_list[0])
        dt = line_list[1]
        ori = line_list[2]
        dest = line_list[3]
        pri = float(line_list[4])

        #create an instance of flight
        new_flight = flight.Flight(flight_num,dt,ori,dest,pri)

        #add the flight to the dictionary
        dictionary[flight_num] = new_flight

    #close the input file
    flight_file.close()

#declare function to view the seat map, passing it the flight num and flight dict
def view_seat_map(flight_num,flight_dic):
    #call the flight's display_seat_map class function
    flight_dic[flight_num].display_seat_map()
    print()

#declare function to cancel a ticket, passing it the flight and ticket dictionaries
def cancel_ticket(flight_dic,ticket_dic):
    #get user input for ticket
    tict_num = int(input('Enter ticket number: '))
    print()

    #validate that the ticket is real
    while tict_num not in ticket_dic:
        #get user input again
        tict_num = int(input('Invalid input. Please enter a valid ticket number: '))
        print()

    #call accessors to get the flight number and seat
    flight = ticket_dic[tict_num].get_flight_number()
    seat = ticket_dic[tict_num].get_seat()

    #call the release_seat class function and store the returned value
    valid = flight_dic[flight].release_seat(seat)

    #while the value is false
    while valid == False:
        #get new ticket number
        tict_num = int(input('Enter ticket number: '))
        print()

        #validate new number
        while tict_num not in ticket_dic:
            #get user input again
            tict_num = int(input('Invalid input. Please enter a valid ticket number: '))
            print()

        #call accessors to get the flight number and seat
        flight = ticket_dic[tict_num].get_flight_number()
        seat = ticket_dic[tict_num].get_seat()

        #call the release_seat class function and store the returned value
        valid = flight_dic[flight].release_seat(seat)
        if valid == False:
            #print error message if false
            print('Error. Seat unoccupied.')
            print()

    #remove the ticket from the dictionary
    del ticket_dic[tict_num]

#declare function to display ticket details, passing it the ticket number, ticket dictionary, and flight dictionary
def view_ticket_details(ticket_num,ticket_dic,flight_dic):
    #call accessors and the calc_price class function to get the ticket details, store them in variables
    name = ticket_dic[ticket_num].get_passenger_name()
    seat = ticket_dic[ticket_num].get_seat()
    flight_num = ticket_dic[ticket_num].get_flight_number()
    date = flight_dic[flight_num].get_date()
    origin = flight_dic[flight_num].get_origin()
    destination = flight_dic[flight_num].get_destination()
    base_price = flight_dic[flight_num].get_price()
    price = format(ticket_dic[ticket_num].calc_price(base_price),',.2f')

    #print the ticket details
    print('Name: ' + name + '\tDate: ' + date + '\tSeat: ' + seat)
    print('Price: $' + str(price) + '\t\tOrigin: ' + origin + '\tDestination: ' + destination)
    print()

#declare function to change seats, passing it the ticket number, ticket dictionary, and flight dictionary
def change_seat(ticket_num,flight_dic,ticket_dic):
    #call accessors to get the flight number and current seat
    flight = ticket_dic[ticket_num].get_flight_number()
    old_seat = ticket_dic[ticket_num].get_seat()

    #call view_seat_map function
    view_seat_map(flight,flight_dic)

    #get user input for the new seat
    new_seat = input('Enter the new seat you would like: ')
    print()

    #validate that the seat is not taken by calling the assign seat class function
    valid = flight_dic[flight].assign_seat(new_seat)
    while valid == False:
        #get user input again and then re-call the assign seat function
        new_seat = input('Enter the new seat you would like: ')
        valid = flight_dic[flight].assign_seat(new_seat)

    #update the ticket with the new seat and orint confirmation message
    ticket_dic[ticket_num].set_seat(new_seat)
    print()
    print('Ticket change successful.')
    print()

    #validate that the old seat was released, if false is returned it means the data was processed improperly
    valid2 = flight_dic[flight].release_seat(old_seat)
    if valid2 == False:
        print('Error loading data.')

#declare function to write the output file, passing it the file name and ticket dictionary        
def write_output(file_name,ticket_dic):
    #open output file
    updated_ticket_file = open(file_name,'w')

    #go through each ticket number from the dictionary
    for num in ticket_dic:
        #call accessors to get the name, flight, and seat
        name = ticket_dic[num].get_passenger_name()
        flight = ticket_dic[num].get_flight_number()
        seat = ticket_dic[num].get_seat()

        #write the ticket details to the output file
        updated_ticket_file.write(str(num) + '^' + name + '^' + str(flight) + '^' + seat + '\n')

    #close output file
    updated_ticket_file.close()

#declare main function
def main():
    #create empty dictionaries
    ticket_dict = {}
    flight_dict = {}

    #call the process file functions for the ticket and flight input file
    process_flights(FLIGHTS_INPUT_FILE,flight_dict)
    process_tickets(TICKETS_INPUT_FILE,ticket_dict,flight_dict)

    #call display_menu function
    print_menu()

    #get the menu choice and store it
    choice = get_menu_option()

    #main while loop, loops until user enters 6
    while choice != DONE:
        #if the user chooses to purchase ticket
        if choice == PURCHASE_TICKET:
            #call the purchase_ticket function, passing the flight/ticket dictionaries
            purchase_ticket(flight_dict,ticket_dict)

        #if the user chooses to cancel ticket
        elif choice == CANCEL_TICKET:
            #call the cancel_ticket function, passing the flight/ticket dictionaries
            cancel_ticket(flight_dict,ticket_dict)

        #if the user chooses to view ticket
        elif choice == VIEW_TICKET:
            #get user input for ticket number
            ticket = int(input('Please enter your ticket number: '))
            print()

            #validate that the ticket is in the dicitonary
            while ticket not in ticket_dict:
                #get user input again
                ticket = int(input('Invalid ticket number. Please enter a valid ticket number: '))
                print()

            #call view_ticket_details, passing the ticket number and the flight/ticket dictionaries
            view_ticket_details(ticket,ticket_dict,flight_dict)

        #if the user chooses to view the seat map
        elif choice == VIEW_SEAT_MAP:
            #get user input for flight number
            flight = int(input('Please enter flight number: '))
            print()

            #validate that the flight is in the dictionary
            while flight not in flight_dict:
                #get user input again
                flight = int(input('Invalid flight number. Please enter a valid flight number: '))
                print()

            #call view_seat_map function
            view_seat_map(flight,flight_dict)

        #if the user chooses to change seat
        else:
            #get user input for ticket number
            ticket = int(input('Please enter your ticket number: '))
            print()

            #validate that the ticket number is in the dictionary
            while ticket not in ticket_dict:
                #get user input again
                ticket = int(input('Invalid ticket number. Please enter a valid ticket number: '))
                print()

            #call change_seat function
            change_seat(ticket,flight_dict,ticket_dict)

        #print menu again
        print_menu()

        #get new menu choice from user
        choice = get_menu_option()

    #write the output after the user is done
    write_output(OUTPUT_FILE,ticket_dict)

#call main function
main()  

