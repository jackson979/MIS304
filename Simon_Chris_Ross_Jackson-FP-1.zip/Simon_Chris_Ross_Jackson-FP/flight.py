#Authors: Chris Simon & Jackson Ross
#Final Project - Airline Ticket Manager
#Due Date: 12/14/17
#Description: This program defines a flight class, with all of the necessary attributes and functions, that is to be used in the main program file.

#declare flight class
class Flight:

    #declare init function
    def __init__(self,flight_no,new_date,new_origin,new_dest,new_price):
        #declare attribute values using parameters
        self.__flight_number = flight_no
        self.__date = new_date
        self.__origin = new_origin
        self.__destination = new_dest
        self.__price = new_price

        #create an empty list for seats to be added to
        self.__seats_taken = []

    #declare flight number accessor
    def get_flight_number(self):
        return self.__flight_number

    #declare date accessor
    def get_date(self):
        return self.__date

    #declare origin accessor
    def get_origin(self):
        return self.__origin
    
    #declare destination accessor
    def get_destination(self):
        return self.__destination

    #declare price accessor
    def get_price(self):
        return self.__price

    #declare function to assign a seat to a flight
    def assign_seat(self,new_seat):
        #use the length of the seat string to determine where the row digits will be
        #and slice the string to get the row number and letter
        if len(new_seat) == 2:
            row = int(new_seat[0])
            letter = new_seat[1]
        elif len(new_seat) == 3:
            row = int(new_seat[0:2])
            letter = new_seat[2]
        else:
            #if the length exceeds the maximum characters allowed (3) return false with an error message
            print('Incorrect number of characters.')
            return False

        #return false if the row is invalid
        if row > 25 or row < 1:
            print('Invalid row. Row values: 1-25')
            return False

        #return false if the letter is invalid
        if letter > 'F' or letter < 'A':
            print('Invalid seat letter. Letters: A-F')
            return False

        #return false if the seat is occupied
        if new_seat in self.__seats_taken:
            print('This seat is currently occupied. Please select a new seat.')
            print()
            return False

        #otherwise return true and add the seat ot the seats_taken list
        else:
            self.__seats_taken.append(new_seat)
            return True

    #declare function to release a seat 
    def release_seat(self,current_seat):
        #if the seat is taken, remove the seat from the seats_taken list and return true
        if current_seat in self.__seats_taken:
            self.__seats_taken.remove(current_seat)
            return True

        #otherwise print that the seat is unoccupied and return false
        else:
            print(current_seat + 'is not currently taken.')
            return False

    #declare function to display a seat map for the flight
    def display_seat_map(self):
        #print header
        print('   ABC DEF')

        #start for loop for rows 1-9
        for row in range(1,10):
            #create a string that will be displayed, starting with the row number
            print_string = str(row)

            #make the strings for later comparison by adding a letter to the end of the row number
            stringa = str(row) + 'A'
            stringb = str(row) + 'B'
            stringc = str(row) + 'C'
            stringd = str(row) + 'D'
            stringe = str(row) + 'E'
            stringf = str(row) + 'F'

            #check to see if the comparison strings match a seat in the seats_taken list
            #add an X to the print string if it's taken or an O if it's untaken; repeat for each letter
            if stringa in self.__seats_taken:
                print_string += '  X'
            else:
                print_string += '  O'
            if stringb in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringc in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringd in self.__seats_taken:
                print_string += ' X'
            else:
                print_string += ' O'
            if stringe in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringf in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'

            #print the print string
            print(print_string)

        #start for loop for rows 10-25
        for row in range(10,26):
            #create a string that will be displayed, starting with the row number
            print_string = str(row)

            #make the strings for later comparison by adding a letter to the end of the row number
            stringa = str(row) + 'A'
            stringb = str(row) + 'B'
            stringc = str(row) + 'C'
            stringd = str(row) + 'D'
            stringe = str(row) + 'E'
            stringf = str(row) + 'F'

            #check to see if the comparison strings match a seat in the seats_taken list
            #add an X to the print string if it's taken or an O if it's untaken; repeat for each letter
            if stringa in self.__seats_taken:
                print_string += ' X'
            else:
                print_string += ' O'
            if stringb in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringc in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringd in self.__seats_taken:
                print_string += ' X'
            else:
                print_string += ' O'
            if stringe in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'
            if stringf in self.__seats_taken:
                print_string += 'X'
            else:
                print_string += 'O'

            #print the print string
            print(print_string)

        #print key for seat map
        print()
        print('X = Taken\tO = Available')

    #declare str function
    def __str__(self):
        #create and return a string with the ticket attributes listed
        string = 'Flight Number: ' + str(self.__flight_number) + '; Date: ' + self.__date + '; Origin: ' + self.__origin + '; Destination: ' + self.__destination + '; Price: ' + str(self.__price)
        return string

